## Virtual Gardening

###  by Reilly Brown

### For this project I created an interactive gardening game. The intended audience is anyone with a passion for flowers and gardening, however the game is more geared toward children. The user will be given an imaginary flower to take care of by adjusting the amount of sunlight, water, and music to increase its mood. The LDR value must be between certain values in order to give the flower the perfect amount of light. If the value is too low, a ‘need more sunlight’ message will be displayed. Further, switch will water the flower. The potentiometer will play music that the flower can dance to to make it happy. Finally, a timer will allow a bee to fly across the screen.




